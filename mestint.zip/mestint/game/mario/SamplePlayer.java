package mario;

import java.util.Random;
import game.mario.Direction;
import game.mario.MarioGame;
import game.mario.MarioPlayer;
import game.mario.utils.MarioState;

public class SamplePlayer extends MarioPlayer {

    private static final int DEPTH = 8;

    public SamplePlayer(int color, Random random, MarioState state) {
        super(color, random, state);
    }

    @Override
    public Direction getDirection(long remainingTime) {

        // ============ PERFECT EDGE JUMP ============
        if (isExactGap(state) || isObstacleAhead(state)) {
            Direction jump = new Direction(MarioGame.RIGHT | MarioGame.UP);
            state.apply(jump);
            return jump;
        }

        // ============ NORMAL LOOKAHEAD ============
        Direction best = new Direction(MarioGame.RIGHT);
        double bestVal = -1e18;

        for (Direction a : new Direction[]{
                new Direction(MarioGame.RIGHT),
                new Direction(MarioGame.RIGHT | MarioGame.UP),
                new Direction(0)
        }) {

            MarioState c = new MarioState(state);
            if (!c.apply(a)) continue;

            double score = simulate(c, DEPTH);
            if (score > bestVal) {
                bestVal = score;
                best = a;
            }
        }

        state.apply(best);
        return best;
    }

    // ===== EXACT EDGE-BASED GAP DETECTION =====
    private boolean isExactGap(MarioState s) {
        int x = (int)s.mario.i;
        int y = (int)s.mario.j;

        if (x+1 >= MarioGame.H || y+1 >= MarioGame.W)
            return false;

        boolean groundNow = (s.map[x+1][y] != MarioGame.EMPTY);
        boolean noGroundNext = (s.map[x+1][y+1] == MarioGame.EMPTY);

        return groundNow && noGroundNext;
    }

    private boolean isObstacleAhead(MarioState s) {
        int x = (int)s.mario.i;
        int y = (int)s.mario.j;

        if (y+1 < MarioGame.W) {
            int cell = s.map[x][y+1];
            if (cell == MarioGame.WALL || cell == MarioGame.PIPE)
                return true;
        }
        return false;
    }

    // ===== SIMULATION =====
    private double simulate(MarioState s, int depth) {
        if (depth == 0 || s.mario.i >= MarioGame.H-1)
            return heuristic(s);

        double best = -1e18;
        for (Direction a : new Direction[]{
                new Direction(MarioGame.RIGHT),
                new Direction(MarioGame.RIGHT | MarioGame.UP),
                new Direction(0)
        }) {
            MarioState n = new MarioState(s);
            if (!n.apply(a)) continue;
            best = Math.max(best, simulate(n, depth-1));
        }
        return best;
    }

    // ===== HEURISTIC =====
    private double heuristic(MarioState s) {
        if (s.mario.i >= MarioGame.H-1)
            return -1e12;

        double v = ((int)s.mario.j) * 100;
        v += coinValue(s);
        return v;
    }

    private double coinValue(MarioState s) {
        double v = 0;
        int x = (int)s.mario.i;
        int y = (int)s.mario.j;

        for (int dy = 1; dy <= 3; dy++) {
            int col = y + dy;
            if (col >= MarioGame.W) break;
            for (int dx = -1; dx <= 1; dx++) {
                int row = x + dx;
                if (row < 0 || row >= MarioGame.H) continue;
                if (s.map[row][col] == MarioGame.COIN)
                    v += 600 - dy*100;
            }
        }
        return v;
    }
}
